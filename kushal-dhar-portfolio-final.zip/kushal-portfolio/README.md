# Kushal Dhar — Personal Developer Portfolio

A responsive premium-minimal portfolio built with plain HTML, CSS and JavaScript. Ready for GitHub Pages.

## Files
- `index.html` — page content and sections
- `style.css` — responsive styling
- `script.js` — mobile navigation and current year
- `assets/Kushal-Dhar-CV.docx` — public-safe CV version prepared from the supplied resume

## Before publishing
1. Your GitHub (`Dharkushal`) and LinkedIn profile links are already added.
2. Review the education status wording. The website follows the uploaded CV: BCA 2025–2029 expected, pursuing (1st Semester).
3. Add real GitHub repository/demo links to project cards only when you have public projects ready.
4. The downloadable public CV omits your home address, date of birth, father's name, religion and personal phone number. Review it before publishing.
5. The CV download button currently downloads the Word document you uploaded. You can replace it with a PDF later if preferred.

## Preview locally
Open `index.html` in a browser, or open the folder in VS Code and use the Live Server extension.

## Publish free with GitHub Pages
1. Create a public GitHub repository named exactly `YOUR-GITHUB-USERNAME.github.io`.
2. Upload the contents of this folder (not the outer ZIP).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Visit `https://YOUR-GITHUB-USERNAME.github.io` after deployment completes.

Google Fonts require an internet connection. No framework or build step is required.
